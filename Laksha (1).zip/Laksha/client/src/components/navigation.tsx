import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Home, TrendingUp, History, User, Plus } from "lucide-react";

export default function Navigation() {
  const [location] = useLocation();

  const navItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/analytics", icon: TrendingUp, label: "Analytics" },
    { path: "/history", icon: History, label: "History" },
    { path: "/profile", icon: User, label: "Profile" },
  ];

  return (
    <nav className="fixed bottom-0 left-1/2 transform -translate-x-1/2 w-full max-w-sm bg-white border-t border-neutral-200 px-6 py-4 z-40">
      <div className="flex justify-around items-center">
        {navItems.map((item, index) => {
          const isActive = location === item.path;
          const IconComponent = item.icon;
          
          if (index === 2) {
            // Add expense button in the middle
            return (
              <div key="add-expense" className="flex flex-col items-center space-y-1">
                <Link href="/expense">
                  <Button 
                    size="icon" 
                    className="w-12 h-12 rounded-2xl shadow-lg transform transition hover:scale-110"
                  >
                    <Plus className="w-6 h-6" />
                  </Button>
                </Link>
              </div>
            );
          }

          return (
            <Link key={item.path} href={item.path}>
              <div className="flex flex-col items-center space-y-1">
                <IconComponent 
                  className={`w-6 h-6 ${
                    isActive ? 'text-primary' : 'text-neutral-400'
                  }`} 
                />
                <span className={`text-xs font-medium ${
                  isActive ? 'text-primary' : 'text-neutral-400'
                }`}>
                  {item.label}
                </span>
              </div>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

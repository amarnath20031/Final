import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useQuery } from "@tanstack/react-query";
import { categoryIcons } from "@/lib/categories";
import { formatCurrency } from "@/lib/currency";
import { Skeleton } from "@/components/ui/skeleton";

export default function CategoryBreakdown() {
  const { data: analytics, isLoading } = useQuery({
    queryKey: ['/api/analytics/spending'],
  });

  const { data: budget } = useQuery({
    queryKey: ['/api/budget'],
  });

  if (isLoading) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Category Breakdown</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Skeleton className="w-10 h-10 rounded-xl" />
                <div>
                  <Skeleton className="h-4 w-24 mb-1" />
                  <Skeleton className="h-3 w-20" />
                </div>
              </div>
              <div className="text-right">
                <Skeleton className="h-4 w-16 mb-1" />
                <Skeleton className="h-3 w-12" />
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  const categorySpending = analytics?.categorySpending || {};
  const budgetAmount = budget ? parseFloat(budget.amount) : 25000;
  
  // Calculate category budgets (default distribution if not set)
  const defaultCategoryBudgets = {
    "Food & Dining": budgetAmount * 0.5,
    "Transport": budgetAmount * 0.3,
    "Groceries": budgetAmount * 0.2,
    "Entertainment": budgetAmount * 0.1,
    "Health": budgetAmount * 0.1,
    "Shopping": budgetAmount * 0.1,
    "Petrol": budgetAmount * 0.15,
    "Mobile Recharge": budgetAmount * 0.05,
  };

  const categoryBudgets = budget?.categoryBudgets 
    ? JSON.parse(budget.categoryBudgets) 
    : defaultCategoryBudgets;

  const sortedCategories = Object.entries(categorySpending)
    .sort(([,a], [,b]) => b - a)
    .slice(0, 6); // Show top 6 categories

  if (sortedCategories.length === 0) {
    return (
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Category Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <p>No expenses recorded yet.</p>
            <p className="text-sm">Start adding expenses to see breakdown.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mb-6">
      <CardHeader>
        <CardTitle>Category Breakdown</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {sortedCategories.map(([category, amount]) => {
          const categoryInfo = categoryIcons[category];
          const categoryBudget = categoryBudgets[category] || 0;
          const percentage = categoryBudget > 0 ? (amount / categoryBudget) * 100 : 0;
          const isOverBudget = percentage > 80;
          
          return (
            <div key={category} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  categoryInfo ? categoryInfo.bgColor : 'bg-gray-100'
                }`}>
                  <i className={`${categoryInfo?.icon || 'fas fa-tag'} ${
                    categoryInfo ? categoryInfo.color : 'text-gray-600'
                  }`}></i>
                </div>
                <div>
                  <p className="font-medium text-neutral-800">{category}</p>
                  <p className="text-sm text-neutral-500">
                    {categoryBudget > 0 ? `Budget: ${formatCurrency(categoryBudget)}` : 'No budget set'}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <p className="font-semibold text-neutral-800">{formatCurrency(amount)}</p>
                <p className={`text-sm ${isOverBudget ? 'text-red-600' : 'text-green-600'}`}>
                  {Math.round(percentage)}% of budget
                </p>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}

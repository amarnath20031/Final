import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { categoryIcons } from "@/lib/categories";
import { formatCurrency } from "@/lib/currency";
import { Skeleton } from "@/components/ui/skeleton";
import { format } from "date-fns";

export default function RecentTransactions() {
  const { data: expenses, isLoading } = useQuery({
    queryKey: ['/api/expenses'],
    queryFn: async () => {
      const response = await fetch('/api/expenses?limit=5');
      if (!response.ok) throw new Error('Failed to fetch expenses');
      return response.json();
    }
  });

  if (isLoading) {
    return (
      <Card className="mb-20">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Recent Transactions</CardTitle>
            <Skeleton className="h-4 w-16" />
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {[1, 2, 3].map((i) => (
            <div key={i} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Skeleton className="w-10 h-10 rounded-xl" />
                <div>
                  <Skeleton className="h-4 w-32 mb-1" />
                  <Skeleton className="h-3 w-24" />
                </div>
              </div>
              <Skeleton className="h-4 w-16" />
            </div>
          ))}
        </CardContent>
      </Card>
    );
  }

  if (!expenses || expenses.length === 0) {
    return (
      <Card className="mb-20">
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle>Recent Transactions</CardTitle>
          </div>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <p>No transactions yet.</p>
            <p className="text-sm">Add your first expense to get started.</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="mb-20">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Recent Transactions</CardTitle>
          <Button variant="ghost" size="sm" className="text-primary">
            View All
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {expenses.map((expense: any) => {
          const categoryInfo = categoryIcons[expense.category];
          const expenseDate = new Date(expense.date);
          const isToday = format(expenseDate, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
          
          return (
            <div key={expense.id} className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${
                  categoryInfo ? categoryInfo.bgColor : 'bg-gray-100'
                }`}>
                  <i className={`${categoryInfo?.icon || 'fas fa-tag'} ${
                    categoryInfo ? categoryInfo.color : 'text-gray-600'
                  }`}></i>
                </div>
                <div>
                  <p className="font-medium text-neutral-800">
                    {expense.description || expense.category}
                  </p>
                  <p className="text-sm text-neutral-500">
                    {isToday ? 'Today' : format(expenseDate, 'MMM dd')}, {format(expenseDate, 'h:mm a')}
                  </p>
                </div>
              </div>
              <span className="font-semibold text-neutral-800">
                {formatCurrency(expense.amount)}
              </span>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}

import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Wallet, TrendingUp, Bell, Mic, Camera, Shield } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary/10 to-secondary/10">
      {/* Header */}
      <header className="px-6 py-8 text-center">
        <div className="w-20 h-20 bg-primary rounded-3xl flex items-center justify-center mx-auto mb-4">
          <Wallet className="text-white w-10 h-10" />
        </div>
        <h1 className="text-3xl font-bold text-neutral-800 mb-2">Laksha</h1>
        <p className="text-neutral-600 text-lg">Smart Budget Tracking for Indians</p>
      </header>

      <div className="px-6 pb-8">
        {/* Hero Section */}
        <Card className="mb-8">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold text-neutral-800 mb-4">
              Take Control of Your Daily Spending
            </h2>
            <p className="text-neutral-600 mb-6">
              Track expenses in rupees, set smart budgets, and get real-time alerts 
              when you're spending too much. Built specifically for Indian users.
            </p>
            <Button 
              className="w-full py-4 text-lg font-semibold h-auto rounded-2xl"
              onClick={() => window.location.href = '/api/login'}
            >
              Get Started
            </Button>
          </CardContent>
        </Card>

        {/* Features */}
        <div className="space-y-4 mb-8">
          <h3 className="text-xl font-semibold text-neutral-800 text-center mb-6">
            Features designed for you
          </h3>
          
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center">
                  <TrendingUp className="text-blue-600 w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-semibold text-neutral-800">Smart Budget Alerts</h4>
                  <p className="text-neutral-600 text-sm">
                    Get notified when you've used 80% of your budget for categories like food, transport, etc.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-green-100 rounded-2xl flex items-center justify-center">
                  <Mic className="text-green-600 w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-semibold text-neutral-800">Voice Input</h4>
                  <p className="text-neutral-600 text-sm">
                    Say "Spent 200 rupees on lunch" and we'll automatically categorize and save it.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center">
                  <Camera className="text-purple-600 w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-semibold text-neutral-800">Receipt Capture</h4>
                  <p className="text-neutral-600 text-sm">
                    Take photos of receipts to quickly add expenses without manual typing.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 bg-orange-100 rounded-2xl flex items-center justify-center">
                  <Shield className="text-orange-600 w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-semibold text-neutral-800">Secure & Private</h4>
                  <p className="text-neutral-600 text-sm">
                    Your financial data is encrypted and stored securely. Only you can access your information.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Indian Categories */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <h4 className="font-semibold text-neutral-800 mb-4">Pre-built Categories for Indian Lifestyle</h4>
            <div className="grid grid-cols-2 gap-3">
              {[
                { name: "Food & Dining", icon: "🍽️" },
                { name: "Transport", icon: "🚗" },
                { name: "Groceries", icon: "🛒" },
                { name: "Petrol", icon: "⛽" },
                { name: "Mobile Recharge", icon: "📱" },
                { name: "Entertainment", icon: "🎬" },
              ].map((category) => (
                <div key={category.name} className="flex items-center space-x-2 p-3 bg-neutral-50 rounded-xl">
                  <span className="text-lg">{category.icon}</span>
                  <span className="text-sm font-medium text-neutral-700">{category.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* CTA */}
        <div className="text-center">
          <p className="text-neutral-600 mb-4">Ready to take control of your spending?</p>
          <Button 
            className="w-full py-4 text-lg font-semibold h-auto rounded-2xl gradient-primary"
            onClick={() => window.location.href = '/api/login'}
          >
            Start Tracking Now
          </Button>
          <p className="text-xs text-neutral-500 mt-4">
            Free to use • Secure login with Replit • No credit card required
          </p>
        </div>
      </div>
    </div>
  );
}
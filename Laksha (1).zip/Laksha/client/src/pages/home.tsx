import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Wallet, Plus, Mic, Bell, LogOut } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import BudgetOverview from "@/components/budget-overview";
import CategoryBreakdown from "@/components/category-breakdown";
import RecentTransactions from "@/components/recent-transactions";
import Navigation from "@/components/navigation";
import VoiceInput from "@/components/voice-input";
import Notification from "@/components/notification";
import { formatCurrency } from "@/lib/currency";

export default function Home() {
  const [location, setLocation] = useLocation();
  const [showVoiceInput, setShowVoiceInput] = useState(false);
  const [notification, setNotification] = useState<{
    title: string;
    message: string;
    type?: 'warning' | 'success' | 'error';
  } | null>(null);
  
  const { user } = useAuth();

  const { data: analytics } = useQuery({
    queryKey: ['/api/analytics/spending'],
    queryFn: async () => {
      const response = await fetch('/api/analytics/spending?period=day');
      if (!response.ok) throw new Error('Failed to fetch analytics');
      return response.json();
    }
  });

  const { data: budget } = useQuery({
    queryKey: ['/api/budget'],
  });

  // Simulate budget alerts
  useEffect(() => {
    const timer = setTimeout(() => {
      if (analytics && budget) {
        const budgetAmount = parseFloat(budget.amount);
        const totalSpent = analytics.totalSpent || 0;
        const percentage = (totalSpent / budgetAmount) * 100;
        
        if (percentage > 80) {
          setNotification({
            title: "Budget Alert!",
            message: `You've used ${Math.round(percentage)}% of your ${budget.type} budget`,
            type: 'warning'
          });
        }
      }
    }, 3000);

    return () => clearTimeout(timer);
  }, [analytics, budget]);

  const handleVoiceInput = (text: string) => {
    // Parse voice input and redirect to expense form with pre-filled data
    // For now, just redirect to expense form
    setLocation('/expense?voice=' + encodeURIComponent(text));
  };

  const dailyLimit = budget?.type === 'daily' 
    ? parseFloat(budget.amount) 
    : parseFloat(budget?.amount || '25000') / 30;
  
  const todaySpent = analytics?.totalSpent || 0;
  const todayPercentage = (todaySpent / dailyLimit) * 100;

  return (
    <div className="min-h-screen bg-neutral-50 pb-24">
      {/* Header */}
      <header className="bg-white px-6 py-4 border-b border-neutral-200">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
              <Wallet className="text-white w-5 h-5" />
            </div>
            <div>
              <h1 className="font-bold text-neutral-800">Laksha</h1>
              <p className="text-sm text-neutral-500">
                Welcome, {user?.firstName || user?.email || 'User'}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" className="w-10 h-10 bg-neutral-100 rounded-xl">
              <Bell className="text-neutral-600 w-5 h-5" />
            </Button>
            <Button 
              variant="ghost" 
              size="icon" 
              className="w-10 h-10 bg-neutral-100 rounded-xl"
              onClick={() => window.location.href = '/api/logout'}
            >
              <LogOut className="text-neutral-600 w-5 h-5" />
            </Button>
          </div>
        </div>
      </header>

      <div className="px-6 py-6">
        {/* Budget Overview */}
        <BudgetOverview />

        {/* Quick Actions */}
        <div className="grid grid-cols-2 gap-4 mb-6">
          <Link href="/expense">
            <Button className="w-full bg-secondary hover:bg-secondary/90 text-white p-4 h-auto flex items-center space-x-3 transform transition hover:scale-105">
              <Plus className="w-5 h-5" />
              <span className="font-semibold">Add Expense</span>
            </Button>
          </Link>
          <Button 
            variant="outline" 
            className="w-full p-4 h-auto flex items-center space-x-3 transform transition hover:scale-105"
            onClick={() => setShowVoiceInput(true)}
          >
            <Mic className="w-5 h-5" />
            <span className="font-semibold">Voice Add</span>
          </Button>
        </div>

        {/* Today's Spending */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-semibold text-neutral-800">Today's Spending</h3>
              <span className="text-sm text-neutral-500">
                {new Date().toLocaleDateString('en-IN', { 
                  month: 'short', 
                  day: 'numeric',
                  year: 'numeric'
                })}
              </span>
            </div>
            
            <div className="flex items-center justify-between mb-4">
              <span className="text-2xl font-bold text-neutral-800">
                {formatCurrency(todaySpent)}
              </span>
              <div className="text-right">
                <p className="text-sm text-neutral-500">Daily Limit</p>
                <p className="font-semibold text-neutral-700">
                  {formatCurrency(dailyLimit)}
                </p>
              </div>
            </div>
            
            <Progress value={Math.min(todayPercentage, 100)} className="h-2" />
          </CardContent>
        </Card>

        {/* Category Breakdown */}
        <CategoryBreakdown />

        {/* Recent Transactions */}
        <RecentTransactions />
      </div>

      {/* Voice Input Modal */}
      <VoiceInput 
        isOpen={showVoiceInput}
        onClose={() => setShowVoiceInput(false)}
        onConfirm={handleVoiceInput}
      />

      {/* Notification */}
      {notification && (
        <Notification
          title={notification.title}
          message={notification.message}
          type={notification.type}
          onClose={() => setNotification(null)}
        />
      )}

      {/* Bottom Navigation */}
      <Navigation />
    </div>
  );
}

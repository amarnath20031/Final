import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ArrowLeft } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBudgetSchema } from "@shared/schema";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { categoryIcons, getDefaultCategories } from "@/lib/categories";
import { formatAmount, parseCurrency } from "@/lib/currency";

const budgetFormSchema = insertBudgetSchema.extend({
  amount: z.string().min(1, "Budget amount is required"),
});

type BudgetFormData = z.infer<typeof budgetFormSchema>;

export default function BudgetSetting() {
  const [location, setLocation] = useLocation();
  const [budgetType, setBudgetType] = useState<'monthly' | 'daily'>('monthly');
  const [categoryBudgets, setCategoryBudgets] = useState<Record<string, number>>({});
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: existingBudget } = useQuery({
    queryKey: ['/api/budget'],
  });

  const form = useForm<BudgetFormData>({
    resolver: zodResolver(budgetFormSchema),
    defaultValues: {
      type: 'monthly',
      amount: existingBudget ? existingBudget.amount : "25000",
      categoryBudgets: existingBudget ? existingBudget.categoryBudgets : "{}",
    },
  });

  // Initialize category budgets based on main budget
  const mainBudgetAmount = parseCurrency(form.watch("amount") || "0");
  
  const getDefaultCategoryBudgets = (totalBudget: number) => ({
    "Food & Dining": totalBudget * 0.5,
    "Transport": totalBudget * 0.3,
    "Groceries": totalBudget * 0.2,
    "Entertainment": totalBudget * 0.1,
    "Health": totalBudget * 0.1,
    "Shopping": totalBudget * 0.1,
    "Petrol": totalBudget * 0.15,
    "Mobile Recharge": totalBudget * 0.05,
  });

  // Update category budgets when main budget changes
  useState(() => {
    if (existingBudget) {
      setBudgetType(existingBudget.type as 'monthly' | 'daily');
      const parsed = JSON.parse(existingBudget.categoryBudgets || "{}");
      setCategoryBudgets(Object.keys(parsed).length > 0 ? parsed : getDefaultCategoryBudgets(parseFloat(existingBudget.amount)));
    } else {
      setCategoryBudgets(getDefaultCategoryBudgets(mainBudgetAmount));
    }
  });

  const saveBudgetMutation = useMutation({
    mutationFn: async (data: BudgetFormData) => {
      const budgetData = {
        ...data,
        type: budgetType,
        amount: parseCurrency(data.amount).toString(),
        categoryBudgets: JSON.stringify(categoryBudgets),
      };
      
      const method = existingBudget ? "PUT" : "POST";
      return apiRequest(method, "/api/budget", budgetData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/budget'] });
      queryClient.invalidateQueries({ queryKey: ['/api/analytics/spending'] });
      toast({
        title: "Budget Updated!",
        description: "Your budget has been saved successfully.",
      });
      setLocation("/");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save budget. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: BudgetFormData) => {
    saveBudgetMutation.mutate(data);
  };

  const handleCategoryBudgetChange = (category: string, value: string) => {
    const amount = parseCurrency(value);
    setCategoryBudgets(prev => ({
      ...prev,
      [category]: amount
    }));
  };

  const handleMainBudgetChange = (value: string) => {
    const amount = parseCurrency(value);
    form.setValue("amount", amount.toString());
    
    // Auto-distribute to categories if they haven't been manually set
    const totalCategoryBudget = Object.values(categoryBudgets).reduce((sum, val) => sum + val, 0);
    if (totalCategoryBudget === 0 || Math.abs(totalCategoryBudget - mainBudgetAmount) < 100) {
      setCategoryBudgets(getDefaultCategoryBudgets(amount));
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between">
        <Link href="/">
          <Button variant="ghost" size="icon" className="w-10 h-10 bg-neutral-100 rounded-xl">
            <ArrowLeft className="text-neutral-600 w-5 h-5" />
          </Button>
        </Link>
        <h2 className="font-semibold text-neutral-800">Set Budget</h2>
        <div className="w-10"></div>
      </header>

      <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col h-screen">
        <div className="flex-1 px-6 py-6">
          {/* Budget Type */}
          <div className="mb-8">
            <Label className="block text-sm font-medium text-neutral-700 mb-3">
              Budget Period
            </Label>
            <div className="grid grid-cols-2 gap-4">
              <Button
                type="button"
                variant={budgetType === 'monthly' ? 'default' : 'outline'}
                className="p-4 font-semibold h-auto"
                onClick={() => setBudgetType('monthly')}
              >
                Monthly
              </Button>
              <Button
                type="button"
                variant={budgetType === 'daily' ? 'default' : 'outline'}
                className="p-4 font-semibold h-auto"
                onClick={() => setBudgetType('daily')}
              >
                Daily
              </Button>
            </div>
          </div>

          {/* Budget Amount */}
          <div className="mb-8">
            <Label className="block text-sm font-medium text-neutral-700 mb-2">
              Budget Amount
            </Label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 transform -translate-y-1/2 text-2xl font-semibold text-neutral-600">
                ₹
              </span>
              <Input
                type="text"
                placeholder="25000"
                className="pl-12 pr-4 py-4 text-2xl font-semibold bg-neutral-50 rounded-2xl border-2 h-auto"
                value={formatAmount(form.watch("amount") || "0")}
                onChange={(e) => handleMainBudgetChange(e.target.value)}
              />
            </div>
            <p className="text-sm text-neutral-500 mt-2">
              Recommended: ₹20,000 - ₹30,000 per month
            </p>
          </div>

          {/* Category Budgets */}
          <div className="mb-8">
            <Label className="block text-sm font-medium text-neutral-700 mb-3">
              Category Wise Budget
            </Label>
            <div className="space-y-4">
              {getDefaultCategories().slice(0, 6).map((category) => {
                const categoryInfo = categoryIcons[category];
                const budgetAmount = categoryBudgets[category] || 0;
                
                return (
                  <div
                    key={category}
                    className="flex items-center justify-between p-4 bg-neutral-50 rounded-2xl"
                  >
                    <div className="flex items-center space-x-3">
                      <i className={`${categoryInfo.icon} ${categoryInfo.color}`}></i>
                      <span className="font-medium">{category}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-neutral-600">₹</span>
                      <Input
                        type="text"
                        value={formatAmount(budgetAmount)}
                        onChange={(e) => handleCategoryBudgetChange(category, e.target.value)}
                        className="w-24 text-right bg-transparent border-none p-0 font-semibold focus:outline-none focus:ring-0"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
            
            <div className="mt-4 p-4 bg-blue-50 rounded-2xl">
              <div className="flex justify-between items-center">
                <span className="font-medium text-blue-900">Total Allocated:</span>
                <span className="font-bold text-blue-900">
                  ₹{formatAmount(Object.values(categoryBudgets).reduce((sum, val) => sum + val, 0))}
                </span>
              </div>
              <div className="flex justify-between items-center mt-1">
                <span className="text-sm text-blue-700">Remaining:</span>
                <span className="text-sm text-blue-700">
                  ₹{formatAmount(mainBudgetAmount - Object.values(categoryBudgets).reduce((sum, val) => sum + val, 0))}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Form Actions */}
        <div className="px-6 py-6 border-t border-neutral-200">
          <Button
            type="submit"
            className="w-full py-4 rounded-2xl font-semibold text-lg h-auto"
            disabled={saveBudgetMutation.isPending}
          >
            {saveBudgetMutation.isPending ? "Saving..." : "Save Budget"}
          </Button>
        </div>
      </form>
    </div>
  );
}

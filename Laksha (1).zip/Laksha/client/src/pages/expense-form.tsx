import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowLeft, Camera, Mic } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertExpenseSchema } from "@shared/schema";
import { z } from "zod";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { categoryIcons, getDefaultCategories } from "@/lib/categories";
import { formatAmount, parseCurrency } from "@/lib/currency";
import VoiceInput from "@/components/voice-input";
import { useCamera } from "@/hooks/use-camera";

const expenseFormSchema = insertExpenseSchema.extend({
  amount: z.string().min(1, "Amount is required"),
});

type ExpenseFormData = z.infer<typeof expenseFormSchema>;

export default function ExpenseForm() {
  const [location, setLocation] = useLocation();
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [showVoiceInput, setShowVoiceInput] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { 
    isOpen: isCameraOpen,
    capturedImage,
    videoRef,
    openCamera,
    capturePhoto,
    closeCamera,
    reset: resetCamera
  } = useCamera();

  const form = useForm<ExpenseFormData>({
    resolver: zodResolver(expenseFormSchema),
    defaultValues: {
      amount: "",
      category: "",
      description: "",
      method: "manual",
      date: new Date(),
    },
  });

  // Parse voice input from URL params
  useEffect(() => {
    const urlParams = new URLSearchParams(location.split('?')[1] || '');
    const voiceText = urlParams.get('voice');
    
    if (voiceText) {
      parseVoiceInput(voiceText);
    }
  }, [location]);

  const parseVoiceInput = (text: string) => {
    // Simple parsing logic - can be enhanced with NLP
    const amountMatch = text.match(/(\d+)\s*(rupees?|rs\.?|₹)/i);
    const categoryKeywords = {
      "food": ["food", "lunch", "dinner", "breakfast", "restaurant", "cafe"],
      "transport": ["uber", "taxi", "bus", "auto", "petrol", "fuel"],
      "groceries": ["grocery", "vegetables", "fruits", "market"],
      "entertainment": ["movie", "cinema", "game", "fun"],
    };
    
    if (amountMatch) {
      form.setValue("amount", amountMatch[1]);
    }
    
    // Find category based on keywords
    const lowerText = text.toLowerCase();
    for (const [category, keywords] of Object.entries(categoryKeywords)) {
      if (keywords.some(keyword => lowerText.includes(keyword))) {
        const fullCategoryName = getDefaultCategories().find(cat => 
          cat.toLowerCase().includes(category)
        ) || category;
        setSelectedCategory(fullCategoryName);
        form.setValue("category", fullCategoryName);
        break;
      }
    }
    
    form.setValue("description", text);
    form.setValue("method", "voice");
  };

  const createExpenseMutation = useMutation({
    mutationFn: async (data: ExpenseFormData) => {
      const expenseData = {
        ...data,
        amount: parseCurrency(data.amount).toString(),
      };
      
      return apiRequest("POST", "/api/expenses", expenseData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/expenses'] });
      queryClient.invalidateQueries({ queryKey: ['/api/analytics/spending'] });
      toast({
        title: "Expense Added!",
        description: "Your expense has been saved successfully.",
      });
      setLocation("/");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save expense. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ExpenseFormData) => {
    if (!selectedCategory) {
      toast({
        title: "Category Required",
        description: "Please select a category for your expense.",
        variant: "destructive",
      });
      return;
    }
    
    createExpenseMutation.mutate({
      ...data,
      category: selectedCategory,
    });
  };

  const handleVoiceInput = (text: string) => {
    parseVoiceInput(text);
    form.setValue("method", "voice");
  };

  const handleAmountChange = (value: string) => {
    // Only allow numbers and decimal point
    const cleaned = value.replace(/[^\d.]/g, '');
    form.setValue("amount", cleaned);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="px-6 py-4 border-b border-neutral-200 flex items-center justify-between">
        <Link href="/">
          <Button variant="ghost" size="icon" className="w-10 h-10 bg-neutral-100 rounded-xl">
            <ArrowLeft className="text-neutral-600 w-5 h-5" />
          </Button>
        </Link>
        <h2 className="font-semibold text-neutral-800">Add Expense</h2>
        <div className="w-10"></div>
      </header>

      <form onSubmit={form.handleSubmit(onSubmit)} className="flex flex-col h-screen">
        <div className="flex-1 px-6 py-6">
          {/* Amount Input */}
          <div className="mb-8">
            <Label className="block text-sm font-medium text-neutral-700 mb-2">
              Amount
            </Label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 transform -translate-y-1/2 text-2xl font-semibold text-neutral-600">
                ₹
              </span>
              <Input
                type="text"
                placeholder="0"
                className="pl-12 pr-4 py-4 text-2xl font-semibold bg-neutral-50 rounded-2xl border-2 h-auto"
                value={form.watch("amount")}
                onChange={(e) => handleAmountChange(e.target.value)}
              />
            </div>
          </div>

          {/* Category Selection */}
          <div className="mb-6">
            <Label className="block text-sm font-medium text-neutral-700 mb-3">
              Category
            </Label>
            <div className="grid grid-cols-3 gap-3">
              {getDefaultCategories().map((category) => {
                const categoryInfo = categoryIcons[category];
                const isSelected = selectedCategory === category;
                
                return (
                  <button
                    key={category}
                    type="button"
                    className={`p-4 rounded-2xl flex flex-col items-center space-y-2 transition-colors ${
                      isSelected 
                        ? 'bg-primary text-white' 
                        : 'bg-neutral-100 hover:bg-neutral-200'
                    }`}
                    onClick={() => setSelectedCategory(category)}
                  >
                    <i className={`${categoryInfo.icon} text-xl`}></i>
                    <span className="text-sm font-medium">
                      {category.split(' ')[0]}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Description */}
          <div className="mb-6">
            <Label className="block text-sm font-medium text-neutral-700 mb-2">
              Description (Optional)
            </Label>
            <Input
              type="text"
              placeholder="Where did you spend?"
              className="w-full px-4 py-4 bg-neutral-50 rounded-2xl border-2 h-auto"
              {...form.register("description")}
            />
          </div>

          {/* Quick Actions */}
          <div className="grid grid-cols-2 gap-4 mb-8">
            <Button
              type="button"
              variant="outline"
              className="p-4 h-auto flex items-center justify-center space-x-2"
              onClick={openCamera}
            >
              <Camera className="w-5 h-5" />
              <span className="font-medium">Take Photo</span>
            </Button>
            <Button
              type="button"
              variant="outline"
              className="p-4 h-auto flex items-center justify-center space-x-2"
              onClick={() => setShowVoiceInput(true)}
            >
              <Mic className="w-5 h-5" />
              <span className="font-medium">Voice Note</span>
            </Button>
          </div>

          {/* Captured Image Preview */}
          {capturedImage && (
            <div className="mb-6">
              <Label className="block text-sm font-medium text-neutral-700 mb-2">
                Receipt Photo
              </Label>
              <Card>
                <CardContent className="p-4">
                  <img 
                    src={capturedImage} 
                    alt="Receipt" 
                    className="w-full h-48 object-cover rounded-lg"
                  />
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    className="mt-2"
                    onClick={resetCamera}
                  >
                    Remove Photo
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}
        </div>

        {/* Camera Modal */}
        {isCameraOpen && (
          <div className="fixed inset-0 bg-black z-50 flex flex-col">
            <div className="flex-1 relative">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full h-full object-cover"
              />
              <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={closeCamera}
                >
                  Cancel
                </Button>
                <Button
                  type="button"
                  onClick={capturePhoto}
                >
                  Capture
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Form Actions */}
        <div className="px-6 py-6 border-t border-neutral-200">
          <Button
            type="submit"
            className="w-full py-4 rounded-2xl font-semibold text-lg h-auto"
            disabled={createExpenseMutation.isPending}
          >
            {createExpenseMutation.isPending ? "Saving..." : "Save Expense"}
          </Button>
        </div>
      </form>

      {/* Voice Input Modal */}
      <VoiceInput
        isOpen={showVoiceInput}
        onClose={() => setShowVoiceInput(false)}
        onConfirm={handleVoiceInput}
      />
    </div>
  );
}

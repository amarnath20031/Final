# Laksha - Indian Budget Tracking App - Replit Configuration

## Overview

Laksha is a full-stack personal expense tracker application built specifically for Indian users. It's designed as a mobile-first Progressive Web App (PWA) that allows users to track expenses in Indian Rupees, set smart budgets, categorize spending, and receive real-time alerts. The app features modern React frontend with Express.js backend, PostgreSQL database for persistence, and Replit Authentication for secure user management.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

The application follows a full-stack architecture optimized for Indian users with secure authentication:

- **Frontend**: React 18 with TypeScript, built using Vite
- **Backend**: Express.js server with TypeScript
- **Database**: PostgreSQL with Drizzle ORM for persistence
- **Authentication**: Replit OpenID Connect for secure user login
- **UI Framework**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query (React Query) for server state
- **Routing**: Wouter for client-side routing
- **Build System**: Vite for frontend, esbuild for backend
- **Session Management**: PostgreSQL-backed session storage

## Key Components

### Frontend Architecture
- **Component Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with custom CSS variables for theming
- **Mobile-First Design**: Optimized for mobile devices with responsive layouts
- **Form Handling**: React Hook Form with Zod validation
- **Navigation**: Bottom navigation with floating action button for expense entry

### Backend Architecture
- **REST API**: Express.js with TypeScript providing RESTful endpoints
- **Database Layer**: Drizzle ORM with PostgreSQL dialect
- **Error Handling**: Centralized error handling middleware
- **Request Logging**: Custom middleware for API request logging
- **Database Migrations**: Drizzle Kit for schema management

### Data Models
The application uses five main database tables:
- **Users**: User profiles with authentication data from Replit
- **Sessions**: Session storage for authentication persistence
- **Budgets**: User budget settings with category-specific allocations
- **Expenses**: Individual expense records with categorization  
- **Categories**: Predefined Indian categories (Food & Dining, Transport, Petrol, etc.)

### Key Features
1. **User Authentication**: Secure login via Replit OpenID Connect
2. **Expense Tracking**: Manual entry, voice input, and receipt photo capture
3. **Budget Management**: Monthly/daily budget setting with category breakdowns
4. **Indian Categories**: Pre-built categories for Indian lifestyle (Petrol, Mobile Recharge, etc.)
5. **Currency Support**: Native Indian Rupee formatting and number system
6. **Voice Integration**: Speech-to-text for quick expense entry in Indian English
7. **Camera Integration**: Receipt photo capture functionality
8. **Real-time Notifications**: Smart budget alerts when spending exceeds 80%
9. **Data Persistence**: All user data saved securely in PostgreSQL

## Data Flow

1. **Expense Entry**: User creates expenses through forms, voice, or camera
2. **Data Validation**: Zod schemas validate input on both client and server
3. **Database Storage**: Drizzle ORM persists data to PostgreSQL
4. **Real-time Updates**: React Query manages cache invalidation and updates
5. **Analytics Generation**: Server aggregates data for spending insights
6. **Budget Monitoring**: Automatic alerts when spending thresholds are reached

## External Dependencies

### Core Framework Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form
- **Backend**: Express.js, Node.js runtime
- **Database**: PostgreSQL via @neondatabase/serverless
- **ORM**: Drizzle ORM with Drizzle Kit for migrations

### UI and Styling
- **Component Library**: Radix UI primitives (@radix-ui/*)
- **Styling**: Tailwind CSS with PostCSS
- **Icons**: Lucide React icons
- **Utilities**: class-variance-authority, clsx, tailwind-merge

### Development Tools
- **Build Tools**: Vite, esbuild, TypeScript
- **Development**: tsx for TypeScript execution
- **Linting/Formatting**: Built-in TypeScript checking

### Browser APIs
- **Speech Recognition**: Web Speech API for voice input
- **Camera Access**: MediaDevices API for receipt capture
- **Local Storage**: For client-side data caching

## Deployment Strategy

### Development Mode
- Frontend served by Vite dev server with HMR
- Backend runs with tsx in watch mode
- Database schema pushed using Drizzle Kit
- Environment variables loaded from .env files

### Production Build
1. **Frontend Build**: Vite builds React app to `dist/public`
2. **Backend Build**: esbuild bundles server to `dist/index.js`
3. **Static Serving**: Express serves built frontend files
4. **Database**: PostgreSQL connection via DATABASE_URL environment variable
5. **Auto-migration**: Database schema automatically updated on startup

### Deployment Strategy
- **Platform**: Render.com with PostgreSQL database
- **Configuration**: render.yaml for infrastructure as code
- **Database**: Persistent PostgreSQL with 1GB storage and daily backups
- **Authentication**: Replit OpenID Connect with custom domain support
- **Environment**: Production-ready with error handling and logging

### Environment Configuration
- **Database**: Requires DATABASE_URL for PostgreSQL connection
- **Development**: NODE_ENV=development enables dev features  
- **Production**: NODE_ENV=production optimizes for deployment
- **Authentication**: REPL_ID and REPLIT_DOMAINS for Replit OAuth
- **Security**: SESSION_SECRET for secure session management
- **Deployment**: Ready for GitHub + Render.com with render.yaml

### Key Architectural Decisions

1. **Mobile-First Design**: Chose mobile-first approach as expense tracking is primarily a mobile use case
2. **In-Memory Storage**: Implemented MemStorage class for development/testing without database dependency
3. **Shared Schema**: TypeScript schema definitions shared between client and server for type safety
4. **Component-Based UI**: Used shadcn/ui for consistent, accessible component library
5. **Real-time State**: TanStack Query provides optimistic updates and cache management
6. **Voice/Camera Integration**: Leveraged modern browser APIs for enhanced user experience
7. **Progressive Enhancement**: Core functionality works without advanced features like voice/camera

The application is designed to scale from simple expense tracking to comprehensive financial management while maintaining a clean, intuitive mobile interface.